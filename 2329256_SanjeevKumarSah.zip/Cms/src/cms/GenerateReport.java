package cms;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class GenerateReport extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JComboBox<String> comboBox;
    private JTable table;
    private JLabel lblAverageMarksValue;
    private JLabel lblGradeValue;

    // Map to store module names for BIT course
    private Map<Integer, String> bitModuleNames;
    // Map to store module names for BIBM course
    private Map<Integer, String> bibmModuleNames;
    private JTextField textField_1;
    private JTextField textField_2;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    GenerateReport frame = new GenerateReport();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public GenerateReport() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Enter Your Student ID");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel.setBounds(63, 27, 139, 27);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField.setBounds(247, 29, 96, 25);
        contentPane.add(textField);
        textField.setColumns(10);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(192, 192, 192));
        panel.setBounds(10, 91, 764, 463);
        contentPane.add(panel);
        panel.setLayout(null);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 121, 744, 282);
        panel.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);
        
        JLabel lblNewLabel_3 = new JLabel("Average Marks");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_3.setBounds(35, 56, 120, 28);
        panel.add(lblNewLabel_3);
        
        textField_1 = new JTextField();
        textField_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField_1.setBounds(138, 55, 70, 34);
        panel.add(textField_1);
        textField_1.setColumns(10);
        
        JLabel lblNewLabel_4 = new JLabel("Grade");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_4.setBounds(416, 58, 70, 24);
        panel.add(lblNewLabel_4);
        
        textField_2 = new JTextField();
        textField_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField_2.setBounds(496, 56, 60, 33);
        panel.add(textField_2);
        textField_2.setColumns(10);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(255, 0, 0));
        panel_1.setBounds(275, 11, 143, 24);
        panel.add(panel_1);
        panel_1.setLayout(null);
        
                JLabel lblNewLabel_2 = new JLabel("Report");
                lblNewLabel_2.setBounds(32, 0, 88, 28);
                panel_1.add(lblNewLabel_2);
                lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
                
                        JButton btnNewButton = new JButton("Generate Report");
                        btnNewButton.setBounds(543, 414, 172, 38);
                        panel.add(btnNewButton);
                        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
                        
                                btnNewButton.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        String studentID = textField.getText();
                                        String course = (String) comboBox.getSelectedItem();
                                        if (studentID.isEmpty()) {
                                            // Show error message dialog if student ID is empty
                                        	JOptionPane.showMessageDialog(GenerateReport.this, "Student name field is empty. Please enter a student name", "Error", JOptionPane.ERROR_MESSAGE);
                                        } else {
                                            generateReport(studentID, course);
                                        }
                                    }
                                });

        JLabel lblNewLabel_1 = new JLabel("Course");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_1.setBounds(556, 24, 49, 32);
        contentPane.add(lblNewLabel_1);

        comboBox = new JComboBox<>();
        comboBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
        comboBox.setModel(new DefaultComboBoxModel<>(new String[] { "BIT", "BIBM" }));
        comboBox.setBounds(635, 30, 49, 22);
        contentPane.add(comboBox);

        // Initialize module names for BIT course
        bitModuleNames = new HashMap<>();
        bitModuleNames.put(1, "Academic Skills and Team-Based Learning");
        bitModuleNames.put(2, "Fundamentals of Computing");
        bitModuleNames.put(3, "Introductory Programming and Problem Solving");
        bitModuleNames.put(4, "Computational Mathematics");
        bitModuleNames.put(5, "Embedded System Programming");
        bitModuleNames.put(6, "Internet Software and Architecture");
        bitModuleNames.put(7, "Concept and Technologies of AI");
        bitModuleNames.put(8, "Numerical Methods and Concurrency");
        bitModuleNames.put(9, "Object-Oriented Design and Programming");
        bitModuleNames.put(10, "Human-Computer Interaction");
        bitModuleNames.put(11, "Collaborative Development");
        bitModuleNames.put(12, "Distributed and Cloud System Programming");
        bitModuleNames.put(13, "High-Performance Computing");
        bitModuleNames.put(14, "Project and Professionalism");
        bitModuleNames.put(15, "Concept of AI");
        bitModuleNames.put(16, "UI/UX");
        bitModuleNames.put(17, " Machine Learning and Artificial Intelligence");
        bitModuleNames.put(18, "High Level Programming");

        // Initialize module names for BIBM course
        bibmModuleNames = new HashMap<>();
        bibmModuleNames.put(1, "21st Century Management");
        bibmModuleNames.put(2, "Preparing For Success at University");
        bibmModuleNames.put(3, "Principles of Business");
        bibmModuleNames.put(4, "Project Based Learning");
        bibmModuleNames.put(5, "The Digital Business");
        bibmModuleNames.put(6, "The Innovative Business");
        bibmModuleNames.put(7, "The Responsible Business");
        bibmModuleNames.put(8, "The Sustainable Business");
        bibmModuleNames.put(9, "Contemporary Issues in International Business");
        bibmModuleNames.put(10, "Managing Finance and Accounts");
        bibmModuleNames.put(11, "Operations and Project Planning");
        bibmModuleNames.put(12, "The International HR Professional");
        bibmModuleNames.put(13, "Global Context For Multinational Enterprises");
        bibmModuleNames.put(14, "The Marketing Consultant");
        bibmModuleNames.put(15, "The Professional Project");
        bibmModuleNames.put(16, "The Strategic Business");

    }

    private void generateReport(String studentID, String course) {
        // Dynamically determine the table name based on the selected course
        String tableName = ("BIT".equals(course)) ? "bit" : "bibm";
        String query = "SELECT * FROM " + tableName + " WHERE student_name = ?";

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, studentID);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                displayReport(resultSet, course);
            } else {
                // Show error message dialog if student not found
                JOptionPane.showMessageDialog(this, "Student not found", "Error", JOptionPane.ERROR_MESSAGE);

                // Clear the table if no data is found
                DefaultTableModel model = new DefaultTableModel();
                table.setModel(model);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error generating report.");
        }
    }

    private void displayReport(ResultSet resultSet, String course) throws SQLException {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Module");
        model.addColumn("Marks");

        // Get module names based on the selected course
        Map<Integer, String> moduleNames = ("BIT".equals(course)) ? bitModuleNames : bibmModuleNames;

        int totalMarks = 0;
        int moduleCount = 0;

        // Iterate through columns and add only those starting with "module_"
        for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
            String columnName = resultSet.getMetaData().getColumnName(i);
            if (columnName.startsWith("module_")) {
                String moduleName = moduleNames.get(Integer.parseInt(columnName.substring(7)));
                int marks = resultSet.getInt(i);

                // Add row only if marks is not null
                if (!resultSet.wasNull()) {
                    model.addRow(new Object[]{moduleName, marks});
                    totalMarks += marks;
                    moduleCount++;
                }
            }
        }

        // Calculate average marks
        double averageMarks = (moduleCount > 0) ? (double) totalMarks / moduleCount : 0;

        // Set the average marks and grade in the text fields
        textField_1.setText(String.format("%.2f", averageMarks));

        // Determine grade remarks based on average marks
        String gradeRemarks;
        if (averageMarks < 40) {
            gradeRemarks = "Fail";
            JOptionPane.showMessageDialog(this, "You Failed the Semester. Can't go to the next Semester.", "Failure", JOptionPane.WARNING_MESSAGE);
        } else if (averageMarks >= 40 && averageMarks < 50) {
            gradeRemarks = "c";
            JOptionPane.showMessageDialog(this, "Not so good.", "Satisfactory", JOptionPane.WARNING_MESSAGE);
        } else if (averageMarks >= 50 && averageMarks < 60) {
            gradeRemarks = "C+";
            JOptionPane.showMessageDialog(this, "Work hard for better.", "Good", JOptionPane.WARNING_MESSAGE);
        } else if (averageMarks >= 60 && averageMarks < 70) {
            gradeRemarks = "B";
            JOptionPane.showMessageDialog(this, "Work Hard.", "V Good", JOptionPane.WARNING_MESSAGE);
        } else if (averageMarks >= 70 && averageMarks < 80) {
            gradeRemarks = "B+";
            JOptionPane.showMessageDialog(this, "Work Hard.", "Very Good", JOptionPane.WARNING_MESSAGE);    
        } else if (averageMarks >= 80 && averageMarks < 90) {
            gradeRemarks = "A";
            JOptionPane.showMessageDialog(this, "Excellent.", "Excellent", JOptionPane.WARNING_MESSAGE);
        } else {
            gradeRemarks = "A+";
            JOptionPane.showMessageDialog(this, "Outstanding .", "Outstanding", JOptionPane.WARNING_MESSAGE);
        }
        
        textField_2.setText(gradeRemarks);

        table.setModel(model);
    }
}