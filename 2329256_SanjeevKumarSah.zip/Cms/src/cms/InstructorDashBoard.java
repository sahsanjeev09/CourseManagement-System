package cms;

import java.awt.Color;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class InstructorDashBoard extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private JLabel titleLabel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                InstructorDashBoard frame = new InstructorDashBoard();
                frame.displayModulesAssigned(); // Call to display student details when the application starts
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public InstructorDashBoard() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 864, 336);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(192, 192, 192));
        panel.setBounds(-15, 0, 229, 293);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("DASHBOARD!!");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel.setBounds(72, 11, 105, 29);
        panel.add(lblNewLabel);

        JButton btnNewButton = new JButton("Modules Assigned");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayModulesAssigned();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnNewButton.setBounds(38, 51, 166, 39);
        panel.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Student Details");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayStudentDetails();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnNewButton_1.setBounds(38, 111, 166, 44);
        panel.add(btnNewButton_1);

        JButton btnNewButton_3 = new JButton("Logout");
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		logout();
        	}
        });
        btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_3.setBounds(72, 238, 105, 44);
        panel.add(btnNewButton_3);
        
        JButton btnNewButton_4 = new JButton("Marks");
        btnNewButton_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Marks marks = new Marks();
                marks.setVisible(true);
        	}
        });
        btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnNewButton_4.setBounds(38, 178, 166, 37);
        panel.add(btnNewButton_4);

        titleLabel = new JLabel("Select an option");
        titleLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        titleLabel.setBounds(433, 11, 200, 29);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(titleLabel);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(224, 39, 618, 246);
        contentPane.add(scrollPane);
    }

    private void displayModulesAssigned() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Teacher_Name");
        model.addColumn("Module_1");
        model.addColumn("Module_2");
        model.addColumn("Module_3");
        model.addColumn("Module_4");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM assigned_modules");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getString("Teacher_Name"),
                        resultSet.getString("Module_1"),
                        resultSet.getString("Module_2"),
                        resultSet.getString("Module_3"),
                        resultSet.getString("Module_4"),
                };
                model.addRow(rowData);
            }

            table.setModel(model);
            titleLabel.setText("Modules Assigned");

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the 'assigned_modules' table.");
        }
    }

    private void displayStudentDetails() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Student Name");
        model.addColumn("Level");
        model.addColumn("Semester");
        model.addColumn("Course");
        model.addColumn("Date");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM student");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getInt("id"),
                        resultSet.getString("student_name"),
                        resultSet.getInt("level"),
                        resultSet.getInt("semester"),
                        resultSet.getString("course"),
                        resultSet.getTimestamp("date")
                };
                model.addRow(rowData);
            }

            table.setModel(model);
            titleLabel.setText("Student Details");

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the 'student' table.");
        }
    }
    
    private void logout() {
        // Perform any logout actions here
        JOptionPane.showMessageDialog(this, "Logged out successfully!");
        // Close the current frame
        this.dispose();
    }
}

