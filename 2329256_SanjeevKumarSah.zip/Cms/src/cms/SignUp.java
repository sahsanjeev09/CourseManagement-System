package cms;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import cms.LoginPage;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.EmptyBorder;

public class SignUp extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textUserName;
    private JTextField textField_1;
    private JComboBox<String> comboBox;
    private JComboBox<String> courseComboBox;
    private JButton btnSignUp;
    private JButton btnLogin;

    public SignUp() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 694, 533);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Welcome To SignUp Panel");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNewLabel.setBounds(161, 52, 270, 27);
        contentPane.add(lblNewLabel);

        JLabel Fullname = new JLabel("Full Name");
        Fullname.setFont(new Font("Tahoma", Font.BOLD, 16));
        Fullname.setBounds(63, 128, 124, 14);
        contentPane.add(Fullname);

        textField = new JTextField();
        textField.setFont(new Font("Tahoma", Font.BOLD, 16));
        textField.setBackground(new Color(192, 192, 192));
        textField.setBounds(254, 127, 232, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel Username = new JLabel("User Name");
        Username.setBackground(new Color(240, 240, 240));
        Username.setFont(new Font("Tahoma", Font.BOLD, 16));
        Username.setBounds(63, 186, 105, 14);
        contentPane.add(Username);

        textUserName = new JTextField();
        textUserName.setFont(new Font("Tahoma", Font.BOLD, 16));
        textUserName.setBackground(new Color(192, 192, 192));
        textUserName.setBounds(254, 185, 232, 20);
        contentPane.add(textUserName);
        textUserName.setColumns(10);

        JLabel Password = new JLabel("Password");
        Password.setFont(new Font("Tahoma", Font.BOLD, 16));
        Password.setBounds(63, 248, 92, 14);
        contentPane.add(Password);

        textField_1 = new JTextField();
        textField_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        textField_1.setBackground(new Color(192, 192, 192));
        textField_1.setBounds(254, 247, 232, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel Mode = new JLabel("Select Mode");
        Mode.setFont(new Font("Tahoma", Font.BOLD, 16));
        Mode.setBounds(63, 306, 105, 14);
        contentPane.add(Mode);

        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 18));
        comboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Admin", "Instructor", "Student"}));
        comboBox.setBackground(new Color(192, 192, 192));
        comboBox.setBounds(254, 304, 232, 22);
        contentPane.add(comboBox);

        JLabel CourseLabel = new JLabel("Select Course");
        CourseLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        CourseLabel.setBounds(63, 360, 124, 14);
        contentPane.add(CourseLabel);

        JComboBox<String> courseComboBox = new JComboBox<>();
        courseComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"BIBM", "BIT"}));
        courseComboBox.setFont(new Font("Tahoma", Font.BOLD, 18));
        courseComboBox.setBackground(new Color(192, 192, 192));
        courseComboBox.setBounds(254, 358, 232, 22);
        contentPane.add(courseComboBox);
        courseComboBox.setVisible(false);

        comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedMode = comboBox.getSelectedItem().toString();
                if ("Student".equals(selectedMode)) {
                    courseComboBox.setVisible(true);
                } else {
                    courseComboBox.setVisible(false);
                }
            }
        });

        btnSignUp = new JButton("SignUp");
        btnSignUp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedMode = comboBox.getSelectedItem().toString();
                String username = textUserName.getText();
                String password = textField_1.getText();
                String selectedCourse = courseComboBox.isVisible() ? courseComboBox.getSelectedItem().toString() : "";

                storeUserData(selectedMode, textField.getText(), username, password, selectedCourse);
            }
        });
        btnSignUp.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnSignUp.setBounds(124, 418, 124, 37);
        contentPane.add(btnSignUp);

        btnLogin = new JButton("Login");
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openLoginPage();
            }
        });
        btnLogin.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnLogin.setBounds(342, 425, 89, 30);
        contentPane.add(btnLogin);
    }

    private void openLoginPage() {
        LoginPage Login = new LoginPage();
        Login.setVisible(true);
        dispose();  // Close the current SignUp frame
    }

    private void storeUserData(String selectedMode, String fullname, String username, String password, String selectedCourse) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "")) {
            String insertSql;

            if ("Admin".equals(selectedMode) || "Instructor".equals(selectedMode) || "Student".equals(selectedMode)) {
                insertSql = "INSERT INTO users (full_name, username, password, course, mode, date) VALUES (?, ?, ?, ?, ?, ?)";
            } else {
                // Handle the case where an invalid mode is selected
                JOptionPane.showMessageDialog(null, "Invalid mode selected.");
                return;
            }

            try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, fullname);
                pstmt.setString(2, username);
                pstmt.setString(3, password);

                if ("Student".equals(selectedMode)) {
                    pstmt.setString(4, selectedCourse);
                    pstmt.setString(5, selectedMode);
                    pstmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
                } else {
                    pstmt.setString(4, null);  // Set course to null for non-student modes
                    pstmt.setString(5, selectedMode);
                    pstmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
                }

                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User data successfully stored!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to store user data. Please try again.");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SignUp frame = new SignUp();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}