package cms;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.DefaultComboBoxModel;

public class CourseForm extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField courseNameTextField;
    private JTextField noOfModulesTextField;
    private JTextField lengthTextField;
	private JComboBox<String> comboBox;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CourseForm frame = new CourseForm();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public CourseForm() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 377, 354);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Course Name");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel.setBounds(10, 87, 154, 28);
        contentPane.add(lblNewLabel);

        JLabel lblNumberOfModules = new JLabel("Number of Modules");
        lblNumberOfModules.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNumberOfModules.setBounds(10, 120, 140, 28);
        contentPane.add(lblNumberOfModules);

        JLabel lblActiveStatus = new JLabel("Active Status");
        lblActiveStatus.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblActiveStatus.setBounds(10, 159, 167, 28);
        contentPane.add(lblActiveStatus);

        JLabel lblNo = new JLabel("Length");
        lblNo.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNo.setBounds(10, 198, 116, 28);
        contentPane.add(lblNo);

        courseNameTextField = new JTextField();
        courseNameTextField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        courseNameTextField.setBounds(174, 92, 179, 20);
        contentPane.add(courseNameTextField);
        courseNameTextField.setColumns(10);

        noOfModulesTextField = new JTextField();
        noOfModulesTextField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        noOfModulesTextField.setBounds(175, 125, 161, 20);
        contentPane.add(noOfModulesTextField);
        noOfModulesTextField.setColumns(10);

        lengthTextField = new JTextField();
        lengthTextField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lengthTextField.setBounds(174, 203, 161, 20);
        contentPane.add(lengthTextField);
        lengthTextField.setColumns(10);

        JButton addCourseBtn = new JButton("Add Course");
        addCourseBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        addCourseBtn.setBounds(135, 259, 154, 36);
        contentPane.add(addCourseBtn);

        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
        comboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Yes", "No"}));
        comboBox.setBounds(174, 163, 57, 22);
        contentPane.add(comboBox);

        JLabel lblNewLabel_1 = new JLabel("ADD COURSE");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel_1.setBounds(97, 11, 217, 28);
        contentPane.add(lblNewLabel_1);

        addCourseBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get values from the UI components
                String courseName = courseNameTextField.getText().trim();
                String noOfModules = noOfModulesTextField.getText().trim();
                String length = lengthTextField.getText().trim();
                String isActivated = comboBox.getSelectedItem().toString();

                try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
                     Statement statement = connection.createStatement()) {

                    // Insert data into the 'course' table
                    String insertQuery = "INSERT INTO course (Course_Name, No_Of_Modules, Active_Status, Length)"
                            + " VALUES ('" + courseName + "', '" + noOfModules + "', '" + isActivated + "', '" + length + "');";
                    int insertSuccess = statement.executeUpdate(insertQuery);

                    if (insertSuccess == 1) {
                        System.out.println("Course added successfully");
                        // You can add further actions or reset the form if needed
                    } else {
                        System.out.println("Error adding course");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public String getCourseName() {
        return courseNameTextField.getText().trim();
    }

    public int getNoOfModules() {
        return 0;
    }

    public String getActiveStatus() {
        return (String) comboBox.getSelectedItem();
    }

    public int getLength() {
        return 0;
    }
}
