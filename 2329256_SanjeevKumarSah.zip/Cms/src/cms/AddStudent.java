package cms;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class AddStudent extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JComboBox<String> comboBox;  // Corrected JComboBox declaration

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AddStudent frame = new AddStudent();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public AddStudent() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 288, 307);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(196, 191, 189));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Add Student");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNewLabel.setBounds(75, 21, 144, 14);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Name");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_1.setBounds(10, 81, 73, 19);
        contentPane.add(lblNewLabel_1);

        textField = new JTextField();
        textField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField.setBounds(106, 81, 144, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Level");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(10, 111, 49, 14);
        contentPane.add(lblNewLabel_2);

        textField_1 = new JTextField();
        textField_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField_1.setBounds(106, 112, 144, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("Semester");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_3.setBounds(10, 141, 89, 14);
        contentPane.add(lblNewLabel_3);

        textField_2 = new JTextField();
        textField_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField_2.setBounds(106, 139, 144, 20);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        JLabel lblNewLabel_4 = new JLabel("Course");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_4.setBounds(10, 172, 73, 14);
        contentPane.add(lblNewLabel_4);

        comboBox = new JComboBox<>();
        comboBox.setModel(new DefaultComboBoxModel<>(new String[]{"BIT", "BIBM"}));
        comboBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
        comboBox.setBounds(106, 170, 60, 22);
        contentPane.add(comboBox);

        JButton btnNewButton = new JButton("ADD");
        btnNewButton.setBackground(new Color(196, 191, 189));
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton.setBounds(106, 227, 89, 23);
        contentPane.add(btnNewButton);

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = getName();
                String level = getLevel();
                String semester = getSemester();
                String course = getCourse();

                storeStudentData(name, level, semester, course);
            }
        });
    }

    private void storeStudentData(String name, String level, String semester, String course) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "")) {
            String insertSql = "INSERT INTO student (student_name, level, semester, course, date) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, level);
                pstmt.setString(3, semester);
                pstmt.setString(4, course);
                pstmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));

                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Student data successfully stored!");
                } else {
                    System.out.println("Failed to store student data. Please try again.");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // Add the following get methods

    public String getName() {
        return textField.getText();
    }

    public String getLevel() {
        return textField_1.getText();
    }

    public String getSemester() {
        return textField_2.getText();
    }

    public String getCourse() {
        return (String) comboBox.getSelectedItem();
    }
}
