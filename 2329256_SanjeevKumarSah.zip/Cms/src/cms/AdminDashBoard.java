package cms;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminDashBoard extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private JLabel titleLabel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                AdminDashBoard frame = new AdminDashBoard();
                frame.displayStudentDetails(); // Call to display student details when the application starts
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public AdminDashBoard() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 826, 405);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(-16, 0, 200, 582);
        panel.setBackground(new Color(192, 192, 192));
        contentPane.add(panel);
        panel.setLayout(null);

        JButton btnNewButton = new JButton("Students");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(30, 57, 151, 38);
        panel.add(btnNewButton);

        JLabel lblNewLabel = new JLabel("DashBoard!!!");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel.setBounds(47, 0, 193, 57);
        panel.add(lblNewLabel);

        JButton btnNewButton_1 = new JButton("Instructors");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayInstructors();
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton_1.setBounds(30, 113, 151, 45);
        panel.add(btnNewButton_1);

        JButton btnNewButton_2 = new JButton("Courses");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayCourses();
            }
        });
        btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton_2.setBounds(30, 179, 151, 45);
        panel.add(btnNewButton_2);
        
        JButton btnNewButton_3 = new JButton("Report");
        btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton_3.setBounds(30, 249, 151, 38);
        panel.add(btnNewButton_3);
        
     // Add the "Generate Report" button
        JButton btnGenerateReport = new JButton("Generate Report");
        btnGenerateReport.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnGenerateReport.setBounds(30, 299, 151, 38);
        btnGenerateReport.setVisible(false); // Initially set to invisible
        panel.add(btnGenerateReport);

        // ActionListener for the "Report" button
        btnNewButton_3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Toggle visibility of the "Generate Report" button
                btnGenerateReport.setVisible(!btnGenerateReport.isVisible());
                
                // If the "Generate Report" button is now visible, you can perform additional actions here
                if (btnGenerateReport.isVisible()) {
                    // Add logic to generate the report or perform other actions
                    // For example, you can display a message or open a new window for report generation
                    JOptionPane.showMessageDialog(contentPane, "Generate Report button is now visible!");
                }
            }
        });

        // ActionListener for the "Generate Report" button
        btnGenerateReport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the GenerateReport form here
                GenerateReport generateReport = new GenerateReport();
                generateReport.setVisible(true);
            }
        });

        
        JButton btnNewButton_4 = new JButton("Logout");
        btnNewButton_4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });
        btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_4.setBounds(30, 317, 151, 38);
        panel.add(btnNewButton_4);

        JButton btnNewButton_5 = new JButton("Delete");
        btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_5.setBounds(514, 282, 126, 39);
        contentPane.add(btnNewButton_5);
        
        btnNewButton_5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedOption = titleLabel.getText();

                // Check the selected option and perform the corresponding delete operation
                if (selectedOption.equals("Student Details")) {
                    deleteStudent();
                } else if (selectedOption.equals("Instructor Details")) {
                    deleteInstructor();
                } else if (selectedOption.equals("Course Details")) {
                    deleteCourse();
                } else {
                    JOptionPane.showMessageDialog(contentPane, "Please select an option before deleting.");
                }
            }
        });

        JButton btnNewButton_6 = new JButton("ADD");
        btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton_6.setBounds(307, 282, 89, 39);
        contentPane.add(btnNewButton_6);
        
     // Add action listener to the ADD button
        btnNewButton_6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Check the title label to determine which button was clicked previously
                String selectedOption = titleLabel.getText();

                // Open the corresponding form based on the selected option
                if (selectedOption.equals("Student Details")) {
                    openAddStudentForm();
                } else if (selectedOption.equals("Instructor Details")) {
                    openAddInstructorForm();
                } else if (selectedOption.equals("Course Details")) {
                    openAddCourseForm();
                }
            }
        });

        titleLabel = new JLabel("Select an option");
        titleLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        titleLabel.setBounds(383, -1, 200, 29);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(titleLabel);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(208, 39, 598, 211);
        contentPane.add(scrollPane);

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayStudentDetails();
            }
        });
    }
    
    
    private void deleteStudent() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(contentPane, "Please select a student to delete.");
            return;
        }

        int studentId = (int) table.getValueAt(selectedRow, 0);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM student WHERE id = ?")) {

            preparedStatement.setInt(1, studentId);
            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(contentPane, "Student deleted successfully!");
                displayStudentDetails(); // Refresh the table after deletion
            } else {
                JOptionPane.showMessageDialog(contentPane, "Error deleting student.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(contentPane, "Error deleting student.");
        }
    }
    
    
    private void deleteInstructor() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(contentPane, "Please select a instructor to delete.");
            return;
        }

        int studentId = (int) table.getValueAt(selectedRow, 0);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM instructor WHERE id = ?")) {

            preparedStatement.setInt(1, studentId);
            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(contentPane, "Instructor deleted successfully!");
                displayStudentDetails(); // Refresh the table after deletion
            } else {
                JOptionPane.showMessageDialog(contentPane, "Error deleting instructor.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(contentPane, "Error deleting instructor.");
        }
    }

    private void deleteCourse() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(contentPane, "Please select a course to delete.");
            return;
        }

        int studentId = (int) table.getValueAt(selectedRow, 0);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM course WHERE Course_id = ?")) {

            preparedStatement.setInt(1, studentId);
            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(contentPane, "Course deleted successfully!");
                displayStudentDetails(); // Refresh the table after deletion
            } else {
                JOptionPane.showMessageDialog(contentPane, "Error deleting course.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(contentPane, "Error deleting course.");
        }
    }
    
    private void openAddStudentForm() {
        // Open the AddStudent form here
        AddStudent addStudent = new AddStudent();
        addStudent.setVisible(true);
    }

    private void openAddInstructorForm() {
        // Open the AddInstructor form here
        AddInstructor addInstructor = new AddInstructor();
        addInstructor.setVisible(true);
    }

    private void openAddCourseForm() {
        // Open the CourseForm here
        CourseForm courseForm = new CourseForm();
        courseForm.setVisible(true);
    }

    private void displayStudentDetails() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Student Name");
        model.addColumn("Level");
        model.addColumn("Semester");
        model.addColumn("Course");
        model.addColumn("Date");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM student");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getInt("id"),
                        resultSet.getString("student_name"),
                        resultSet.getInt("level"),
                        resultSet.getInt("semester"),
                        resultSet.getString("course"),
                        resultSet.getTimestamp("date")
                };
                model.addRow(rowData);
            }

            displayTable("Student Details", model);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the 'student' table.");
        }
    }

    private void displayInstructors() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Full Name");
        model.addColumn("Phone Number");
        model.addColumn("Address");
        model.addColumn("Module Assigned");
        model.addColumn("Time");
        model.addColumn("Date");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM instructor");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getInt("id"),
                        resultSet.getString("full_name"),
                        resultSet.getString("phone_number"),
                        resultSet.getString("address"),
                        resultSet.getString("module_assigned"),
                        resultSet.getString("time"),
                        resultSet.getTimestamp("date")
                };
                model.addRow(rowData);
            }

            displayTable("Instructor Details", model);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the 'instructor' table.");
        }
    }

    private void displayCourses() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Course ID");
        model.addColumn("Course Name");
        model.addColumn("No_Of_Modules");
        model.addColumn("Active Status");
        model.addColumn("Length");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM course");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getInt("Course_id"),
                        resultSet.getString("Course_Name"),
                        resultSet.getInt("No_Of_Modules"),
                        resultSet.getString("Active_Status"),
                        resultSet.getInt("Length"),
                };
                model.addRow(rowData);
            }

            displayTable("Course Details", model);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the 'course' table.");
        }
    }

    private void displayTable(String title, DefaultTableModel model) {
        titleLabel.setText(title);

        // Remove the old JScrollPane if it exists
        Component[] components = contentPane.getComponents();
        for (Component component : components) {
            if (component instanceof JScrollPane) {
                contentPane.remove(component);
                break;  // Assuming there is only one JScrollPane
            }
        }

        // Create and set up the new table
        table = new JTable(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getColumnModel().getColumn(0).setPreferredWidth(70);

        JScrollPane newScrollPane = new JScrollPane(table);
        newScrollPane.setBounds(208, 39, 598, 211);
        contentPane.add(newScrollPane);

        contentPane.revalidate();
        contentPane.repaint();
    }

    private void logout() {
        // Perform any logout actions here
        JOptionPane.showMessageDialog(this, "Logged out successfully!");
        // Close the current frame
        this.dispose();
    }
}
