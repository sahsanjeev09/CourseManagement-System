package cms;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.EmptyBorder;

public class LoginPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textUsername;
    private JTextField textPassword;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/management";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LoginPage frame = new LoginPage();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private boolean checkCredentials(String username, String password, String selectedMode) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "")) {
            String selectSql = "SELECT * FROM users WHERE username = ? AND password = ? AND mode = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(selectSql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                pstmt.setString(3, selectedMode);

                try (ResultSet rs = pstmt.executeQuery()) {
                    return rs.next(); // Returns true if the user exists, false otherwise
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

//    private boolean checkCredentials(String username, String password, String selectedMode) {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "")) {
//            // Correct table name in the query
//            String selectSql = "SELECT * FROM " + selectedMode.toLowerCase() + " WHERE username = ? AND password = ?";
//            try (PreparedStatement pstmt = conn.prepareStatement(selectSql)) {
//                pstmt.setString(1, username);
//                pstmt.setString(2, password);
//
//                try (ResultSet rs = pstmt.executeQuery()) {
//                    return rs.next(); // Returns true if the user exists, false otherwise
//                }
//            }
//        } catch (Exception ex) {
//            ex.printStackTrace();
//            return false;
//        }
//    }

    public LoginPage() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 301, 288);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel Username = new JLabel("Username");
        Username.setFont(new Font("Tahoma", Font.BOLD, 16));
        Username.setBounds(10, 69, 93, 36);
        contentPane.add(Username);

        textUsername = new JTextField();
        textUsername.setFont(new Font("Tahoma", Font.BOLD, 16));
        textUsername.setBackground(new Color(192, 192, 192));
        textUsername.setBounds(121, 77, 152, 20);
        contentPane.add(textUsername);
        textUsername.setColumns(10);

        JLabel Password = new JLabel("Password");
        Password.setFont(new Font("Tahoma", Font.BOLD, 16));
        Password.setBounds(10, 108, 93, 25);
        contentPane.add(Password);

        textPassword = new JTextField();
        textPassword.setFont(new Font("Tahoma", Font.BOLD, 16));
        textPassword.setBackground(new Color(192, 192, 192));
        textPassword.setBounds(121, 110, 152, 20);
        contentPane.add(textPassword);
        textPassword.setColumns(10);

        JLabel SelectMode = new JLabel("Select Mode");
        SelectMode.setFont(new Font("Tahoma", Font.BOLD, 16));
        SelectMode.setBounds(10, 144, 105, 25);
        contentPane.add(SelectMode);

        JComboBox<String> comboBox = new JComboBox<String>();
        comboBox.setModel(new DefaultComboBoxModel<String>(new String[]{"Admin", "Instructor", "Student"}));
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 18));
        comboBox.setBounds(121, 144, 152, 22);
        contentPane.add(comboBox);

        JButton btnCreate = new JButton("Create");
        btnCreate.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnCreate.setBounds(26, 210, 89, 23);
        contentPane.add(btnCreate);

        JButton btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnLogin.setBounds(192, 210, 89, 23);
        contentPane.add(btnLogin);

        JLabel lblNewLabel = new JLabel("Welcome To CMS");
        lblNewLabel.setBackground(new Color(0, 128, 255));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNewLabel.setBounds(121, 11, 175, 45);
        contentPane.add(lblNewLabel);

        btnCreate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SignUp signUpPage = new SignUp();
                signUpPage.setVisible(true);
                dispose();
            }
        });

        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = textUsername.getText();
                String password = textPassword.getText();
                String selectedMode = comboBox.getSelectedItem().toString();

                boolean loginSuccessful = checkCredentials(username, password, selectedMode);

                if (loginSuccessful) {
                    JOptionPane.showMessageDialog(null, "Successfully logged in!");

                    // Open the respective dashboard based on the selected mode
                    switch (selectedMode) {
                        case "Admin":
                            AdminDashBoard adminDashboard = new AdminDashBoard();
                            adminDashboard.setVisible(true);
                            break;
                        case "Instructor":
                            InstructorDashBoard instructorDashboard = new InstructorDashBoard();
                            instructorDashboard.setVisible(true);
                            break;
                        case "Student":
                            StudentDashBoard studentDashboard = new StudentDashBoard();
                            studentDashboard.setVisible(true);
                            break;
                    }

                    // Close the login page
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Sorry, login failed. Please check your credentials.");
                }
            }
        });


    }
}

