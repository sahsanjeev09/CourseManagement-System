package cms;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentDashBoard extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private JPanel coursesPanel;
    private JPanel mainPanel;
    private JLabel titleLabel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                StudentDashBoard frame = new StudentDashBoard();
                frame.displayModulesAssigned();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public StudentDashBoard() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 779, 369);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new CardLayout(0, 0));

        mainPanel = new JPanel();
        mainPanel.setBackground(new Color(192, 192, 192));
        contentPane.add(mainPanel, "name_298922550262100");
        mainPanel.setLayout(null);

        JLabel lblNewLabel = new JLabel("DashBoard");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 22));
        lblNewLabel.setBounds(35, 35, 136, 27);
        mainPanel.add(lblNewLabel);

        JButton btnCourses = new JButton("Courses");
        btnCourses.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Modules modules = new Modules();
                modules.setVisible(true);
        	}
        });
        btnCourses.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnCourses.setBounds(35, 94, 136, 31);
        mainPanel.add(btnCourses);

        JButton btnInstructors = new JButton("Instructors");
        btnInstructors.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayModulesAssigned();
            }
        });
        btnInstructors.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnInstructors.setBounds(35, 146, 136, 36);
        mainPanel.add(btnInstructors);

        JPanel panel_1 = new JPanel();
        panel_1.setBounds(203, 56, 544, 230);
        mainPanel.add(panel_1);
        panel_1.setLayout(null);

        titleLabel = new JLabel("Select an option");
        titleLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        titleLabel.setBounds(433, 11, 200, 29);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(titleLabel);

        table = new JTable();
        table.setBounds(10, 11, 520, 200);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 11, 520, 200);
        panel_1.add(scrollPane);

        JButton btnResult = new JButton("Result");
        btnResult.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		GenerateReport Report = new GenerateReport();
                Report.setVisible(true);
        	}
        });
        btnResult.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnResult.setBounds(35, 193, 136, 42);
        mainPanel.add(btnResult);

        JButton btnLogout = new JButton("Logout");
        btnLogout.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		logout();
        	}
        });
        btnLogout.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnLogout.setBounds(35, 274, 136, 36);
        mainPanel.add(btnLogout);
    }

    private void displayModulesAssigned() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Teacher_Name");
        model.addColumn("Module_1");
        model.addColumn("Module_2");
        model.addColumn("Module_3");
        model.addColumn("Module_4");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM assigned_modules");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getString("Teacher_Name"),
                        resultSet.getString("Module_1"),
                        resultSet.getString("Module_2"),
                        resultSet.getString("Module_3"),
                        resultSet.getString("Module_4"),
                };
                model.addRow(rowData);
            }

            table.setModel(model);
            titleLabel.setText("Modules Assigned");

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the 'assigned_modules' table.");
        }
    }

    
    private void logout() {
        // Perform any logout actions here
        JOptionPane.showMessageDialog(this, "Logged out successfully!");
        // Close the current frame
        this.dispose();
    }
}
