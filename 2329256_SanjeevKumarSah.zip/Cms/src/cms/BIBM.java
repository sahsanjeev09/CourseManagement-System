package cms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

public class BIBM extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BIBM frame = new BIBM();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BIBM() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1001, 372);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(196, 191, 189));
		panel.setBounds(10, 70, 209, 254);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Level 4");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(46, 11, 101, 30);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("21st Century Management");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(10, 78, 252, 30);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Preparing for Success at University ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(10, 119, 322, 30);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Principles of Business");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(10, 160, 252, 30);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Project Based Learning");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(10, 201, 252, 30);
		panel.add(lblNewLabel_4);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(196, 191, 189));
		panel_1.setBounds(241, 70, 161, 254);
		contentPane.add(panel_1);
		
		JLabel lblLevel = new JLabel("Level 5");
		lblLevel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblLevel.setBounds(37, 11, 101, 30);
		panel_1.add(lblLevel);
		
		JLabel lblNewLabel_1_1 = new JLabel("The Digital Business");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(10, 71, 226, 30);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("The Innovative Business");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1.setBounds(10, 112, 210, 30);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("The Responsible Business");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_1.setBounds(10, 153, 210, 30);
		panel_1.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("The Sustainable Business");
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4_1.setBounds(10, 194, 219, 30);
		panel_1.add(lblNewLabel_4_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(196, 191, 189));
		panel_2.setBounds(416, 70, 274, 254);
		contentPane.add(panel_2);
		
		JLabel lblLevel_1 = new JLabel("Level 6");
		lblLevel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblLevel_1.setBounds(68, 11, 101, 35);
		panel_2.add(lblLevel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Contemporary Issues in International Business");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_2.setBounds(10, 72, 385, 30);
		panel_2.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_2_2 = new JLabel("Managing Finance and Accounts");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_2.setBounds(10, 113, 272, 30);
		panel_2.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_3_2 = new JLabel("Operations and Project  Planning");
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_2.setBounds(10, 154, 272, 30);
		panel_2.add(lblNewLabel_3_2);
		
		JLabel lblNewLabel_4_2 = new JLabel("The International HR Professional");
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4_2.setBounds(10, 195, 281, 30);
		panel_2.add(lblNewLabel_4_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBackground(new Color(196, 191, 189));
		panel_3.setBounds(709, 70, 255, 254);
		contentPane.add(panel_3);
		
		JLabel lblLevel_2 = new JLabel("Level 7");
		lblLevel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblLevel_2.setBounds(69, 11, 101, 30);
		panel_3.add(lblLevel_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Global Context for Multinational Enterprises");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_3.setBounds(10, 69, 364, 30);
		panel_3.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_2_3 = new JLabel("The Marketing Consultant");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_3.setBounds(10, 110, 353, 30);
		panel_3.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_3_3 = new JLabel("The Professional Project");
		lblNewLabel_3_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3.setBounds(10, 151, 375, 30);
		panel_3.add(lblNewLabel_3_3);
		
		JLabel lblNewLabel_4_3 = new JLabel("The Strategic Business");
		lblNewLabel_4_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4_3.setBounds(10, 192, 331, 30);
		panel_3.add(lblNewLabel_4_3);
		
		JLabel lblNewLabel_5 = new JLabel("Courses Offered to BIBM Students");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_5.setBounds(391, 21, 335, 29);
		contentPane.add(lblNewLabel_5);
	}

}
