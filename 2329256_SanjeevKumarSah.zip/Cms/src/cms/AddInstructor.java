package cms;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.EmptyBorder;

public class AddInstructor extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JComboBox<String> comboBox;
    private JComboBox<String> comboBox_1;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AddInstructor frame = new AddInstructor();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public AddInstructor() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 340, 365);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("ADD INSTRUCTOR");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel.setBounds(111, 11, 173, 41);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Full Name");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_1.setBounds(10, 81, 96, 25);
        contentPane.add(lblNewLabel_1);

        textField = new JTextField();
        textField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField.setBounds(126, 83, 182, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Phone Number");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(10, 115, 129, 25);
        contentPane.add(lblNewLabel_2);

        textField_1 = new JTextField();
        textField_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField_1.setBounds(126, 117, 182, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("Address");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_3.setBounds(10, 151, 118, 25);
        contentPane.add(lblNewLabel_3);

        textField_2 = new JTextField();
        textField_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textField_2.setBounds(126, 151, 182, 20);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        JLabel lblNewLabel_4 = new JLabel("Module Assigned");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_4.setBounds(10, 187, 139, 25);
        contentPane.add(lblNewLabel_4);

        comboBox = new JComboBox<>();
        comboBox.setModel(new DefaultComboBoxModel<String>(
                new String[]{"Numerical Methods and Concurrency", "Concept and Technologies of AI",
                        "Object-Oriented Design and Programming", "Internet Software Architecture",
                        "Embedded System Programming", "Academic Skills and Team Based Learning"}));
        comboBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
        comboBox.setBounds(126, 187, 182, 22);
        contentPane.add(comboBox);

        JLabel lblNewLabel_5 = new JLabel("Time");
        lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_5.setBounds(10, 223, 49, 25);
        contentPane.add(lblNewLabel_5);

        comboBox_1 = new JComboBox<>();
        comboBox_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        comboBox_1.setModel(new DefaultComboBoxModel<>(new String[]{"Part", "Full"}));
        comboBox_1.setBounds(126, 223, 49, 22);
        contentPane.add(comboBox_1);

        JButton btnNewButton = new JButton("ADD");
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton.setBounds(126, 271, 89, 41);
        contentPane.add(btnNewButton);

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String fullName = getFullName();
                String phoneNumber = getPhoneNumber();
                String address = getAddress();
                String moduleAssigned = getModuleAssigned();
                String time = getTime();

                storeInstructorData(fullName, phoneNumber, address, moduleAssigned, time);
            }
        });
    }

    private void storeInstructorData(String fullName, String phoneNumber, String address, String moduleAssigned,
            String time) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "")) {
            String insertSql = "INSERT INTO instructor (full_name, phone_number, address, module_assigned, time, date) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, fullName);
                pstmt.setString(2, phoneNumber);
                pstmt.setString(3, address);
                pstmt.setString(4, moduleAssigned);
                pstmt.setString(5, time);
                pstmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));

                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Instructor data successfully stored!");
                } else {
                    System.out.println("Failed to store instructor data. Please try again.");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getFullName() {
        return textField.getText();
    }

    public String getPhoneNumber() {
        return textField.getText();
    }

    public String getAddress() {
        return textField_2.getText();
    }

    public String getModuleAssigned() {
        return (String) comboBox.getSelectedItem();
    }

    public String getTime() {
        return (String) comboBox_1.getSelectedItem();
    }
}
