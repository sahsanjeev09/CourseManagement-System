package cms;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Marks extends JFrame {

    private JPanel contentPane;
    private JTextField textName;
    private JPanel panel_1;
    private JComboBox<String> comboBox_1;
    private Map<String, JTextField> moduleTextFields = new HashMap<>();

    private static final String DB_URL = "jdbc:mysql://localhost:3306/management";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Marks frame = new Marks();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Marks() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 607, 660);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 255, 255));
        panel.setBounds(-18, 0, 1031, 724);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("Student Name");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel.setBounds(23, 50, 146, 27);
        panel.add(lblNewLabel);

        textName = new JTextField();
        textName.setFont(new Font("Tahoma", Font.PLAIN, 12));
        textName.setBounds(130, 54, 163, 20);
        panel.add(textName);
        textName.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Level");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_1.setBounds(317, 50, 68, 27);
        panel.add(lblNewLabel_1);

        JComboBox<String> comboBox = new JComboBox<String>();
        comboBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
        comboBox.setModel(new DefaultComboBoxModel(new String[]{"4", "5", "6", "7"}));
        comboBox.setBounds(374, 53, 44, 22);
        panel.add(comboBox);

        panel_1 = new JPanel();
        panel_1.setBounds(79, 91, 509, 447);
        panel.add(panel_1);
        panel_1.setLayout(null);

        // Initialize modules for level 4
        initializeModules(4, "BIT");

        comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Clear existing modules
                panel_1.removeAll();

                // Get the selected level from the combo box
                int selectedLevel = Integer.parseInt((String) comboBox.getSelectedItem());

                // Initialize modules for the selected level and course
                initializeModules(selectedLevel, (String) comboBox_1.getSelectedItem());

                // Repaint the panel
                panel_1.revalidate();
                panel_1.repaint();
            }
        });

        JButton btnNewButton = new JButton("ADD");
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnNewButton.setBounds(317, 561, 89, 33);
        panel.add(btnNewButton);

        JLabel lblNewLabel_2 = new JLabel("Course");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(449, 47, 83, 33);
        panel.add(lblNewLabel_2);

        comboBox_1 = new JComboBox();
        comboBox_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        comboBox_1.setModel(new DefaultComboBoxModel(new String[]{"BIT", "BIBM"}));
        comboBox_1.setBounds(509, 53, 56, 22);
        panel.add(comboBox_1);

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String studentName = textName.getText();
                int level = Integer.parseInt((String) comboBox.getSelectedItem());
                String course = (String) comboBox_1.getSelectedItem();

                // Check if the student exists
                if (isStudentExists(studentName, level, course)) {
                    // Get module marks
                    Map<String, Integer> moduleMarks = new HashMap<>();
                    for (Component component : panel_1.getComponents()) {
                        if (component instanceof JLabel) {
                            JLabel label = (JLabel) component;
                            String moduleName = label.getText();

                            JTextField textField = findTextFieldByLabel(moduleName);

                            // Check if the text field is empty
                            String textFieldValue = textField.getText().trim();
                            if (!textFieldValue.isEmpty()) {
                                // Parse the value if not empty
                                moduleMarks.put(moduleName, Integer.parseInt(textFieldValue));
                            } else {
                                // Module field is empty, set default value (0)
                                moduleMarks.put(moduleName, 0);
                            }
                        }
                    }

                    // Insert marks into the database based on course
                    if ("BIT".equals(course)) {
                        insertDataBit(studentName, level, moduleMarks);
                    } else if ("BIBM".equals(course)) {
                        insertDataBibm(studentName, level, moduleMarks);
                    }

                } else {
                    System.out.println("Student does not exist. Marks not added.");
                }
            }
        });
    }

    private void initializeModules(int level, String selectedCourse) {
        // Clear the map before adding new modules
        moduleTextFields.clear();

        // Add your modules based on the selected level and course
        switch (level) {
            case 4:
                if ("BIT".equals(selectedCourse)) {
                    addModule("Academic Skills and Team-Based Learning", 43);
                    addModule("Fundamentals of Computing", 94);
                    addModule("Introductory Programming and Problem Solving", 150);
                    addModule("Computational Mathematics", 209);
                    addModule("Embedded System Programming", 263);
                    addModule("Internet Software and Architecture", 317);
                } else if ("BIBM".equals(selectedCourse)) {
                    addModule("21st Century Management", 43);
                    addModule("Preparing For Success at University", 94);
                    addModule("Principles of Business", 150);
                    addModule("Project Based Learning", 209);
                }
                break;
            case 5:
                if ("BIT".equals(selectedCourse)) {
                    addModule("Concept and Technologies of AI", 43);
                    addModule("Numerical Methods and Concurrency", 94);
                    addModule("Object-Oriented Design and Programming", 150);
                    addModule("Human-Computer Interaction", 209);
                    addModule("Collaborative Development", 263);
                    addModule("Distributed and Cloud System Programming", 317);
                } else if ("BIBM".equals(selectedCourse)) {
                    addModule("The Digital Business", 43);
                    addModule("The Innovative Business", 94);
                    addModule("The Responsible Business", 150);
                    addModule("The Sustainable Business", 209);
                }
                break;
            case 6:
                if ("BIT".equals(selectedCourse)) {
                    addModule("High-Performance Computing", 43);
                    addModule("Project and Professionalism", 94);

                    JComboBox<String> comboBox1 = new JComboBox<String>();
                    comboBox1.setBackground(new Color(196, 191, 189));
                    comboBox1.setModel(new DefaultComboBoxModel<String>(new String[]{"Concept of AI", "UI/UX"}));
                    comboBox1.setFont(new Font("Tahoma", Font.BOLD, 16));
                    comboBox1.setBounds(10, 130, 300, 39);
                    panel_1.add(comboBox1);

                    JTextField textField1 = new JTextField();
                    textField1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                    textField1.setBounds(410, 130, 96, 20);
                    panel_1.add(textField1);
                    textField1.setColumns(10);

                    JComboBox<String> comboBox2 = new JComboBox<String>();
                    comboBox2.setBackground(new Color(196, 191, 189));
                    comboBox2.setFont(new Font("Tahoma", Font.BOLD, 16));
                    comboBox2.setModel(new DefaultComboBoxModel<String>(new String[]{"Machine Learning and Artificial Intelligence", "High Level Programming"}));
                    comboBox2.setBounds(10, 180, 300, 39);
                    panel_1.add(comboBox2);

                    JTextField textField2 = new JTextField();
                    textField2.setFont(new Font("Tahoma", Font.PLAIN, 16));
                    textField2.setBounds(410, 180, 96, 20);
                    panel_1.add(textField2);

                    // Store the additional text fields in the map
                    moduleTextFields.put("Concept of AI", textField1);
                    moduleTextFields.put("UI/UX", textField1);
                    moduleTextFields.put("Machine Learning and Artificial Intelligence", textField2);
                    moduleTextFields.put("High Level Programming", textField2);
                } else if ("BIBM".equals(selectedCourse)) {
                    addModule("Contemporary Issues in International Business", 43);
                    addModule("Managing Finance and Accounts", 94);
                    addModule("Operations and Project Planning", 150);
                    addModule("The International HR Professional", 209);
                }
                break;
            case 7:
                if ("BIBM".equals(selectedCourse)) {
                    addModule("Global Context For Multinational Enterprises", 43);
                    addModule("The Marketing Consultant", 94);
                    addModule("The Professional Project", 150);
                    addModule("The Strategic Business", 209);
                }
            default:
                break;
        }
    }

    private void addModule(String moduleName, int yPosition) {
        JLabel label = new JLabel(moduleName);
        label.setFont(new Font("Tahoma", Font.PLAIN, 16));
        label.setBounds(10, yPosition, 400, 27);
        panel_1.add(label);

        JTextField textField = new JTextField();
        textField.setFont(new Font("Tahoma", Font.PLAIN, 16));
        textField.setBounds(410, yPosition, 96, 20);
        panel_1.add(textField);
        textField.setColumns(10);

        // Sanitize the module name to create a valid column name
        String sanitizedModuleName = moduleName.replaceAll("[^a-zA-Z0-9]", "_");

        // Store the text field in the map with the sanitizedModuleName as the key
        moduleTextFields.put(sanitizedModuleName, textField);
    }

    private void insertDataBit(String studentName, int level, Map<String, Integer> moduleMarks) {
        // Build the base part of the query
        StringBuilder queryBuilder = new StringBuilder("INSERT INTO `bit` (`student_name`, `course`");

        // Determine the module index range based on the selected level
        int startModuleIndex;
        int endModuleIndex;
        switch (level) {
            case 4:
                startModuleIndex = 1;
                endModuleIndex = 6;
                break;
            case 5:
                startModuleIndex = 7;
                endModuleIndex = 12;
                break;
            case 6:
                startModuleIndex = 13;
                endModuleIndex = 18;
                break;
            default:
                System.out.println("Invalid level");
                return;
        }

        // Add placeholders for module marks
        for (int i = startModuleIndex; i <= endModuleIndex; i++) {
            queryBuilder.append(", `module_").append(i).append("`");
        }

        queryBuilder.append(") VALUES (?, ?");

        // Add placeholders for module marks
        for (int i = startModuleIndex; i <= endModuleIndex; i++) {
            queryBuilder.append(", ?");
        }

        queryBuilder.append(")");

        // Execute the query
     // Execute the query
     // Execute the query
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement(queryBuilder.toString())) {

            preparedStatement.setString(1, studentName);
            preparedStatement.setString(2, "BIT"); // Hardcoded for BIT course

            int parameterIndex = 3;
            for (Map.Entry<String, Integer> entry : moduleMarks.entrySet()) {
                preparedStatement.setObject(parameterIndex++, entry.getValue());
            }

            preparedStatement.executeUpdate();
            System.out.println("Marks added to 'bit' table successfully.");

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error adding marks to 'bit' table.");
        }

    }

    private void insertDataBibm(String studentName, int level, Map<String, Integer> moduleMarks) {
        // Build the base part of the query
        StringBuilder queryBuilder = new StringBuilder("INSERT INTO `bibm` (`student_name`, `course`");

        // Determine the module index range based on the selected level
        int startModuleIndex;
        int endModuleIndex;
        switch (level) {
            case 4:
                startModuleIndex = 1;
                endModuleIndex = 4;
                break;
            case 5:
                startModuleIndex = 5;
                endModuleIndex = 8;
                break;
            case 6:
                startModuleIndex = 9;
                endModuleIndex = 12;
                break;
            case 7:
                startModuleIndex = 13;
                endModuleIndex = 16;
                break;
            default:
                System.out.println("Invalid level");
                return;
        }

        // Add placeholders for module marks
        for (int i = startModuleIndex; i <= endModuleIndex; i++) {
            queryBuilder.append(", `module_").append(i).append("`");
        }

        queryBuilder.append(") VALUES (?, ?");

        // Add placeholders for module marks
        for (int i = startModuleIndex; i <= endModuleIndex; i++) {
            queryBuilder.append(", ?");
        }

        queryBuilder.append(")");

        // Execute the query
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement(queryBuilder.toString())) {

            preparedStatement.setString(1, studentName);
            preparedStatement.setString(2, "BIBM"); // Hardcoded for BIBM course

            int parameterIndex = 3;
            for (Map.Entry<String, Integer> entry : moduleMarks.entrySet()) {
                preparedStatement.setObject(parameterIndex++, entry.getValue());
            }

            preparedStatement.executeUpdate();
            System.out.println("Marks added to 'bibm' table successfully.");

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error adding marks to 'bibm' table.");
        }
    }

    private JTextField findTextFieldByLabel(String moduleName) {
        // Sanitize the module name to create a valid column name
        String sanitizedModuleName = moduleName.replaceAll("[^a-zA-Z0-9]", "_");

        return moduleTextFields.get(sanitizedModuleName);
    }

    private boolean isStudentExists(String studentName, int level, String course) {
        String query = "SELECT * FROM student WHERE student_name = ? AND level = ? AND course = ?";
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "");
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, studentName);
            preparedStatement.setInt(2, level);
            preparedStatement.setString(3, course);

            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error checking student existence.");
            return false;
        }
    }
}
